package com.example.sps;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sps.databinding.ActivityMainBinding;
import com.example.sps.databinding.ActivitySignInBinding;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    TextView rChances, yScore, dScore;
    Button b1, b2, b3;
    int player1 = 0, player2 = 0, j = 5;
    ActivityMainBinding binding;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rChances = findViewById(R.id.tv0);
        yScore = findViewById(R.id.tv1);
        dScore = findViewById(R.id.tv2);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        String name = getIntent().getStringExtra("NAME");
        binding.textView12.setText(name+"'s score");
        //updateUI();

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playGame("Stone");
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playGame("Paper");
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playGame("Scissor");
            }
        });
    }

    private void playGame(String playerChoice) {
        if (j > 0) {
            j--;
            String[] strings = {"Stone", "Paper", "Scissor"};
            Random random = new Random();
            int index = random.nextInt(strings.length);
            String computerChoice = strings[index];
            showToast("Computer Selected " + computerChoice + " :");

            if (playerChoice.equals(computerChoice)) {
                // It's a draw
            } else if ((playerChoice.equals("Stone") && computerChoice.equals("Scissor")) ||
                    (playerChoice.equals("Paper") && computerChoice.equals("Stone")) ||
                    (playerChoice.equals("Scissor") && computerChoice.equals("Paper"))) {
                // Player wins
                player1 += 5;
            } else {
                // Computer wins
                player2 += 5;
            }

            updateUI();

            if (j == 0) {
                if (player1 > player2) {
                    showToast("You Woned The Game");
                } else if (player1 < player2) {
                    showToast("Computer Woned The Game");
                } else {
                    showToast("Match got Draw, Both Players Earned Equal Points");
                }
                final Handler handler = new Handler(Looper.getMainLooper());
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        //Do something after 100ms
                        resetGame();
                    }
                }, 10000);

            }
        }
    }

    private void updateUI() {
        rChances.setText("" + j);
        yScore.setText("" + player1);
        dScore.setText("" + player2);
    }

    private void resetGame() {
        j = 5;
        player1 = 0;
        player2 = 0;
        updateUI();
    }

    private void showToast(String message) {
        Toast toast = Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT);
        toast.setGravity(Gravity.TOP, 0, 0);
        toast.show();
    }

}
